# Student-Scheduler

## What needs done still:
* assignments(?)
* auth_session (Can be removed, implemented manually on each page)
* settings

<br> feel free to add anything else!
