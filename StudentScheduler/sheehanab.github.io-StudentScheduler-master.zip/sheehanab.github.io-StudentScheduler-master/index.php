<!-- Initial page loaded when navigating to localhost/Student-Scheduler/ -->
<?php header("Location: login.php"); ?>
