<!-- checks to see if user has a session set up before allowing passage to a page -->
